import cv2
import numpy as np
from sklearn.cluster import MiniBatchKMeans
import matplotlib.pyplot as plt

# --- Config ---
image_path = "C:/Users/ljube/Desktop/Veles_Sense/Projekti/EmpoWomen/implementation/Thermal_implementation/2025_06_Plavinci/Plavinci_06_2025_60m.jpg"

resize_factor = 0.25
k = 3

# --- Load grayscale thermal image ---
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
if image is None:
    raise ValueError("Could not load image.")

h, w = image.shape
resized = cv2.resize(image, (int(w * resize_factor), int(h * resize_factor)))
display_image = cv2.cvtColor(resized.copy(), cv2.COLOR_GRAY2BGR)

roi_points = []
roi_closed = False

# --- Mouse handler ---
def mouse_callback(event, x, y, flags, param):
    global roi_points, roi_closed
    if roi_closed:
        return
    if event == cv2.EVENT_LBUTTONDOWN:
        pt = (int(x / resize_factor), int(y / resize_factor))
        roi_points.append(pt)
        cv2.circle(display_image, (x, y), 3, (0, 255, 0), -1)
        if len(roi_points) > 1:
            cv2.line(display_image,
                     (int(roi_points[-2][0] * resize_factor), int(roi_points[-2][1] * resize_factor)),
                     (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor)),
                     (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_image)
    elif event == cv2.EVENT_LBUTTONDBLCLK:
        roi_closed = True
        if len(roi_points) > 2:
            cv2.line(display_image,
                     (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor)),
                     (int(roi_points[0][0] * resize_factor), int(roi_points[0][1] * resize_factor)),
                     (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_image)

# --- ROI Selection ---
cv2.namedWindow("Draw ROI (double-click to finish)")
cv2.setMouseCallback("Draw ROI (double-click to finish)", mouse_callback)
cv2.imshow("Draw ROI (double-click to finish)", display_image)
print("Click to draw polygon. Double-click to close ROI.")
while not roi_closed:
    cv2.waitKey(10)
cv2.destroyAllWindows()

if len(roi_points) < 3:
    raise ValueError("At least 3 points are needed to form a polygon.")

# --- Create binary mask from polygon ---
mask = np.zeros((h, w), dtype=np.uint8)
cv2.fillPoly(mask, [np.array(roi_points, dtype=np.int32)], 255)

# --- Extract ROI pixels only ---
roi_pixels = image[mask == 255].reshape(-1, 1).astype(np.float32)

# --- Apply MiniBatchKMeans ---
model = MiniBatchKMeans(n_clusters=k, random_state=0, batch_size=100)
labels = model.fit_predict(roi_pixels)

# --- Color map for clusters (BGR) ---
colors = {
    0: (255, 0, 0),    # Blue
    1: (0, 255, 0),    # Green
    2: (0, 0, 255),    # Red
    3: (255, 255, 0),  # Cyan if k=4
    4: (255, 0, 255)   # Magenta if k=5
}

# --- Reconstruct color image from labels inside ROI only ---
color_result = np.zeros((h, w, 3), dtype=np.uint8)
flat = color_result.reshape(-1, 3)
roi_indices = np.flatnonzero(mask.flatten())

for i, idx in enumerate(roi_indices):
    flat[idx] = colors.get(labels[i], (255, 255, 255))  # white as default

color_result = flat.reshape((h, w, 3))

# --- Show result ---
plt.figure(figsize=(6, 6))
plt.title(f"MiniBatchKMeans in ROI (k={k})")
plt.imshow(cv2.cvtColor(color_result, cv2.COLOR_BGR2RGB))
plt.axis('off')
plt.tight_layout()
plt.show()


# New color scheme
# --- Color map for clusters (thermal-like: cold to hot) ---
thermal_colors = {
    0: (255, 0, 0),      # Cold (blue)
    1: (255, 165, 0),    # Medium (orange)
    2: (0, 255, 255),    # Warm (yellow/cyan)
    3: (0, 0, 255),      # Hot (red)
    4: (255, 255, 255)   # White (very hot, optional 5th class)
}
# --- Reconstruct color image using thermal color scheme ---
color_result = np.zeros((h, w, 3), dtype=np.uint8)
flat = color_result.reshape(-1, 3)
roi_indices = np.flatnonzero(mask.flatten())

for i, idx in enumerate(roi_indices):
    label = labels[i]
    color = thermal_colors.get(label, (0, 0, 0))  # default = black if unknown
    flat[idx] = color

color_result = flat.reshape((h, w, 3))

plt.figure(figsize=(6, 6))
plt.title(f"MiniBatchKMeans (Thermal Colors) in ROI")
plt.imshow(cv2.cvtColor(color_result, cv2.COLOR_BGR2RGB))
plt.axis('off')
plt.tight_layout()
plt.show()

