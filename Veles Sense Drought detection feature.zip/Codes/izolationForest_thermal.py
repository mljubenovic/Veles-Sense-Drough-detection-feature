import cv2
import numpy as np
from sklearn.ensemble import IsolationForest
import matplotlib.pyplot as plt

# --- Config ---
image_path = "C:/Users/ljube/Desktop/Veles_Sense/Projekti/EmpoWomen/implementation/Thermal_implementation/2025_06_Plavinci/Plavinci_06_2025_60m.jpg"

resize_factor = 0.25
contamination = 0.01  # percentage of pixels to consider outliers

# --- Load grayscale thermal image ---
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
if image is None:
    raise ValueError("Image could not be loaded.")

h, w = image.shape
resized = cv2.resize(image, (int(w * resize_factor), int(h * resize_factor)))
display_img = cv2.cvtColor(resized.copy(), cv2.COLOR_GRAY2BGR)

roi_points = []
roi_done = False

# --- Mouse callback ---
def mouse_callback(event, x, y, flags, param):
    global roi_points, roi_done
    if roi_done:
        return
    if event == cv2.EVENT_LBUTTONDOWN:
        pt = (int(x / resize_factor), int(y / resize_factor))
        roi_points.append(pt)
        cv2.circle(display_img, (x, y), 3, (0, 255, 0), -1)
        if len(roi_points) > 1:
            cv2.line(display_img,
                     (int(roi_points[-2][0] * resize_factor), int(roi_points[-2][1] * resize_factor)),
                     (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor)),
                     (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_img)
    elif event == cv2.EVENT_LBUTTONDBLCLK:
        roi_done = True
        if len(roi_points) > 2:
            cv2.line(display_img,
                     (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor)),
                     (int(roi_points[0][0] * resize_factor), int(roi_points[0][1] * resize_factor)),
                     (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_img)

# --- Start ROI selection ---
cv2.namedWindow("Draw ROI (double-click to finish)")
cv2.setMouseCallback("Draw ROI (double-click to finish)", mouse_callback)
cv2.imshow("Draw ROI (double-click to finish)", display_img)
print("Click to define ROI. Double-click to close.")
while not roi_done:
    cv2.waitKey(10)
cv2.destroyAllWindows()

if len(roi_points) < 3:
    raise ValueError("At least 3 points needed for polygon.")

# --- Create ROI mask ---
mask = np.zeros((h, w), dtype=np.uint8)
cv2.fillPoly(mask, [np.array(roi_points, dtype=np.int32)], 255)

# --- Extract ROI pixel values ---
roi_pixels = image[mask == 255].reshape(-1, 1).astype(np.float32)

# --- Apply Isolation Forest for outlier detection ---
iso_forest = IsolationForest(contamination=contamination, random_state=0)
outlier_labels = iso_forest.fit_predict(roi_pixels)  # -1 = outlier, 1 = inlier

# --- Create binary outlier mask ---
outlier_mask = np.zeros_like(image, dtype=np.uint8)
roi_indices = np.flatnonzero(mask.flatten())
for i, idx in enumerate(roi_indices):
    if outlier_labels[i] == -1:
        outlier_mask.flat[idx] = 255

# --- Display original and outlier result ---
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.title("Original Thermal Image")
plt.imshow(image, cmap='gray')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.title(f"Detected Outliers (ROI only)\nContamination: {contamination}")
plt.imshow(outlier_mask, cmap='gray')
plt.axis('off')

plt.tight_layout()
plt.show()
