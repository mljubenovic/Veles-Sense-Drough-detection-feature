import cv2
import numpy as np
import torch
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# Load thermal image
image_path = "C:/Users/ljube/Desktop/Veles_Sense/Projekti/EmpoWomen/implementation/Thermal_implementation/2025_06_Plavinci/Plavinci_06_2025_60m.jpg"

resize_factor = 0.25
k = 3

# --- Load thermal grayscale image ---
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
if image is None:
    raise ValueError("Image could not be loaded.")

h, w = image.shape
resized = cv2.resize(image, (int(w * resize_factor), int(h * resize_factor)))
display_image = cv2.cvtColor(resized.copy(), cv2.COLOR_GRAY2BGR)

roi_points = []
roi_closed = False

def mouse_callback(event, x, y, flags, param):
    global roi_points, roi_closed
    if roi_closed:
        return
    if event == cv2.EVENT_LBUTTONDOWN:
        full_point = (int(x / resize_factor), int(y / resize_factor))
        roi_points.append(full_point)
        cv2.circle(display_image, (x, y), 3, (0, 255, 0), -1)
        if len(roi_points) > 1:
            pt1 = (int(roi_points[-2][0] * resize_factor), int(roi_points[-2][1] * resize_factor))
            pt2 = (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor))
            cv2.line(display_image, pt1, pt2, (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_image)
    elif event == cv2.EVENT_LBUTTONDBLCLK:
        roi_closed = True
        if len(roi_points) > 2:
            pt1 = (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor))
            pt2 = (int(roi_points[0][0] * resize_factor), int(roi_points[0][1] * resize_factor))
            cv2.line(display_image, pt1, pt2, (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_image)

# --- ROI Selection ---
cv2.namedWindow("Draw ROI (double-click to finish)")
cv2.setMouseCallback("Draw ROI (double-click to finish)", mouse_callback)
cv2.imshow("Draw ROI (double-click to finish)", display_image)
print("Click to mark points. Double-click to close ROI.")
while not roi_closed:
    cv2.waitKey(10)
cv2.destroyAllWindows()

if len(roi_points) < 3:
    raise ValueError("At least 3 points are needed to form a polygon.")

# --- Create binary mask ---
mask = np.zeros((h, w), dtype=np.uint8)
cv2.fillPoly(mask, [np.array(roi_points, dtype=np.int32)], 255)

# --- Extract ROI pixels only ---
roi_pixels = image[mask == 255].reshape(-1, 1).astype(np.float32)

# --- Apply KMeans ONLY on ROI pixels ---
kmeans = KMeans(n_clusters=k, random_state=0, n_init='auto')
labels = kmeans.fit_predict(roi_pixels)
centroids = np.uint8(kmeans.cluster_centers_)

# --- Rebuild ROI image with cluster values ---
roi_result = np.zeros_like(image)
roi_flat = roi_result.flatten()
roi_indices = np.flatnonzero(mask.flatten())
for i, idx in enumerate(roi_indices):
    roi_flat[idx] = centroids[labels[i]]
roi_result = roi_flat.reshape((h, w))

# --- Display ONLY clustered ROI (rest is black) ---
plt.figure(figsize=(8, 6))
plt.title(f"KMeans Result in ROI (k={k})")
plt.imshow(roi_result, cmap='inferno')  # Try 'hot', 'viridis', etc.
plt.axis('off')
plt.tight_layout()
plt.show()


# --- Display complete clustered ROI ---
plt.figure(figsize=(14, 4))
plt.subplot(1, k + 1, 1)
plt.title("KMeans Result (Full ROI)")
plt.imshow(roi_result, cmap='inferno')
plt.axis('off')

# --- Show separate binary masks for each cluster ---
for i in range(k):
    cluster_mask = np.zeros_like(image, dtype=np.uint8)
    cluster_flat = cluster_mask.flatten()
    for j, idx in enumerate(roi_indices):
        if labels[j] == i:
            cluster_flat[idx] = 255
    cluster_mask = cluster_flat.reshape((h, w))

    plt.subplot(1, k + 1, i + 2)
    plt.title(f"Cluster {i}")
    plt.imshow(cluster_mask, cmap='gray')
    plt.axis('off')

plt.tight_layout()
plt.show()

# --- Define fixed RGB colors for clusters ---
cluster_colors = {
    0: (255, 0, 0),    # Blue
    1: (0, 255, 0),    # Green
    2: (0, 0, 255)     # Red
}

# --- Initialize blank RGB image ---
roi_colored_result = np.zeros((h, w, 3), dtype=np.uint8)

# --- Map KMeans labels to colored pixels only in ROI ---
roi_indices = np.flatnonzero(mask.flatten())
roi_colored_flat = roi_colored_result.reshape(-1, 3)

for i, idx in enumerate(roi_indices):
    label = labels[i]
    color = cluster_colors.get(label, (255, 255, 255))  # default white if more than 3 clusters
    roi_colored_flat[idx] = color

roi_colored_result = roi_colored_flat.reshape((h, w, 3))

# --- Show the RGB result ---
plt.figure(figsize=(6, 6))
plt.title("KMeans Colored Clusters (ROI only)")
plt.imshow(cv2.cvtColor(roi_colored_result, cv2.COLOR_BGR2RGB))
plt.axis('off')
plt.tight_layout()
plt.show()


