import cv2
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

tif_path = Path("C:/Users/ljube/Desktop/Veles_Sense/Projekti/EmpoWomen/implementation/Thermal_implementation/Data/2025_08_Aleksandrovac/Surface model.rgb Smiljkovic.TIF")

def percentile_stretch(img, p_low=2, p_high=98):
    """Robust contrast stretch per-channel to [0,1]."""
    img = img.astype(np.float32)
    if img.ndim == 2:  # single band
        lo, hi = np.percentile(img, [p_low, p_high])
        return np.clip((img - lo) / max(hi - lo, 1e-6), 0, 1)
    else:  # multi-channel
        out = np.zeros_like(img, dtype=np.float32)
        for c in range(img.shape[2]):
            lo, hi = np.percentile(img[..., c], [p_low, p_high])
            out[..., c] = np.clip((img[..., c] - lo) / max(hi - lo, 1e-6), 0, 1)
        return out

# --- Load (preserve bit depth & color) ---
# IMREAD_UNCHANGED keeps original dtype (e.g., uint16) and channels
img = cv2.imread(str(tif_path), cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH | cv2.IMREAD_ANYCOLOR)

if img is None:
    raise FileNotFoundError(f"Could not read: {tif_path}")

print(f"Shape: {img.shape}, dtype: {img.dtype}")

# If it's multi-page, consider cv2.imreadmulti:
# ok, pages = cv2.imreadmulti(str(tif_path), [], cv2.IMREAD_UNCHANGED)
# (Most single-page TIFFs will be fine with imread above.)

# --- Convert BGR->RGB if 3 or 4 channels ---
if img.ndim == 3 and img.shape[2] == 3:
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
elif img.ndim == 3 and img.shape[2] == 4:
    img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGBA)

# --- Diagnostics (to explain "values seem off") ---
if img.ndim == 2:
    print("Min/Max:", np.min(img), np.max(img))
    print("P2/P98:", *np.percentile(img, [2, 98]))
else:
    for c in range(img.shape[2]):
        chan = img[..., c]
        print(f"Channel {c}: Min/Max {chan.min()} / {chan.max()}  |  P2/P98 {np.percentile(chan, 2)} / {np.percentile(chan, 98)}")

# --- Contrast stretch to see details ---
vis = percentile_stretch(img, 2, 98)

# --- Display ---
plt.figure(figsize=(8, 8))
if vis.ndim == 2:
    # Use a perceptual colormap so it’s not plain black/white
    plt.imshow(vis, cmap="viridis")
else:
    plt.imshow(vis)  # already in [0,1] RGB
plt.title("TIFF (percentile-stretched for display)")
plt.axis("off")
plt.show()
