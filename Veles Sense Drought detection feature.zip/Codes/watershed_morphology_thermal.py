import cv2
import numpy as np
import matplotlib.pyplot as plt

# --- Load thermal image in grayscale ---
image_path = "C:/Users/ljube/Desktop/Veles_Sense/Projekti/EmpoWomen/implementation/Thermal_implementation/2025_06_Plavinci/Plavinci_06_2025_60m.jpg"

gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
if gray is None:
    raise ValueError("Image could not be loaded.")

h, w = gray.shape
roi_points = []
roi_done = False
resize_factor = 0.25  # For easier ROI drawing
resized = cv2.resize(gray, (int(w * resize_factor), int(h * resize_factor)))
display_img = cv2.cvtColor(resized.copy(), cv2.COLOR_GRAY2BGR)

# --- Mouse callback to select polygon ---
def mouse_callback(event, x, y, flags, param):
    global roi_points, roi_done
    if roi_done:
        return
    if event == cv2.EVENT_LBUTTONDOWN:
        pt = (int(x / resize_factor), int(y / resize_factor))
        roi_points.append(pt)
        cv2.circle(display_img, (x, y), 3, (0, 255, 0), -1)
        if len(roi_points) > 1:
            cv2.line(display_img,
                     (int(roi_points[-2][0] * resize_factor), int(roi_points[-2][1] * resize_factor)),
                     (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor)),
                     (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_img)
    elif event == cv2.EVENT_LBUTTONDBLCLK:
        roi_done = True
        if len(roi_points) > 2:
            cv2.line(display_img,
                     (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor)),
                     (int(roi_points[0][0] * resize_factor), int(roi_points[0][1] * resize_factor)),
                     (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_img)

cv2.namedWindow("Draw ROI (double-click to finish)")
cv2.setMouseCallback("Draw ROI (double-click to finish)", mouse_callback)
cv2.imshow("Draw ROI (double-click to finish)", display_img)
print("Click to mark ROI points. Double-click to finish.")
while not roi_done:
    cv2.waitKey(10)
cv2.destroyAllWindows()

if len(roi_points) < 3:
    raise ValueError("At least 3 points needed for ROI.")

# --- Create ROI mask ---
mask = np.zeros((h, w), dtype=np.uint8)
cv2.fillPoly(mask, [np.array(roi_points, dtype=np.int32)], 255)

# --- Extract ROI image ---
roi_image = cv2.bitwise_and(gray, gray, mask=mask)

# --- CLAHE enhancement ---
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
enhanced = clahe.apply(roi_image)

# --- Adaptive thresholding ---
thresh = cv2.adaptiveThreshold(enhanced, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                               cv2.THRESH_BINARY, 11, 2)

# --- Morphology ---
kernel = np.ones((3, 3), np.uint8)
opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=2)
sure_bg = cv2.dilate(opening, kernel, iterations=3)

# --- Distance transform for foreground ---
dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
ret, sure_fg = cv2.threshold(dist_transform, 0.05 * dist_transform.max(), 255, 0)
sure_fg = np.uint8(sure_fg)
unknown = cv2.subtract(sure_bg, sure_fg)

# --- Marker labelling ---
ret, markers = cv2.connectedComponents(sure_fg)
markers = markers + 1
markers[unknown == 255] = 0

# --- Prepare image for watershed ---
roi_color = cv2.cvtColor(roi_image, cv2.COLOR_GRAY2BGR)
cv2.watershed(roi_color, markers)

# --- Generate result with distinct colors ---
segmented = np.zeros_like(roi_color)
unique_labels = np.unique(markers)
colors = {label: np.random.randint(0, 255, size=3) for label in unique_labels if label > 1}

for label in unique_labels:
    if label > 1:
        segmented[markers == label] = colors[label]
segmented[markers == -1] = [0, 0, 255]  # Red boundaries

# --- Mask background outside ROI ---
segmented[mask == 0] = 0
roi_color[mask == 0] = 0

# --- Show results ---
plt.figure(figsize=(12, 5))
plt.subplot(1, 3, 1)
plt.title("Original ROI")
plt.imshow(roi_image, cmap='gray')
plt.axis('off')

plt.subplot(1, 3, 2)
plt.title("Watershed Borders in ROI")
plt.imshow(cv2.cvtColor(roi_color, cv2.COLOR_BGR2RGB))
plt.axis('off')

plt.subplot(1, 3, 3)
plt.title("Segmented ROI")
plt.imshow(cv2.cvtColor(segmented, cv2.COLOR_BGR2RGB))
plt.axis('off')

plt.tight_layout()
plt.show()


