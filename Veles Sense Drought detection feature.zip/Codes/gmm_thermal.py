import cv2
import numpy as np
from sklearn.mixture import GaussianMixture
import matplotlib.pyplot as plt
import rasterio

# --- Config ---
image_path = "C:/Users/ljube/Desktop/Veles_Sense/Projekti/EmpoWomen/implementation/Thermal_implementation/Data/2025_08_08_Radovanovic/2025_08_08_Radovanovic_Termal_DrugaVikendica_1ha_50m_ortho.TIF"

resize_factor = 0.25
k = 4  # number of GMM components

# --- Load grayscale image ---
# image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
# if image is None:
#    raise ValueError("Could not load image.")

# Open the TIF file
with rasterio.open(image_path) as src:
    # Read the first band
    image = src.read(1)

    # Show basic metadata
    print("Width:", src.width)
    print("Height:", src.height)
    print("CRS:", src.crs)
    print("Number of bands:", src.count)

h, w = image.shape
resized = cv2.resize(image, (int(w * resize_factor), int(h * resize_factor)))
display_img = cv2.cvtColor(resized.copy(), cv2.COLOR_GRAY2BGR)

roi_points = []
roi_done = False

# --- Mouse callback to define ROI ---
def mouse_callback(event, x, y, flags, param):
    global roi_points, roi_done
    if roi_done:
        return
    if event == cv2.EVENT_LBUTTONDOWN:
        full_point = (int(x / resize_factor), int(y / resize_factor))
        roi_points.append(full_point)
        cv2.circle(display_img, (x, y), 3, (0, 255, 0), -1)
        if len(roi_points) > 1:
            cv2.line(display_img,
                     (int(roi_points[-2][0] * resize_factor), int(roi_points[-2][1] * resize_factor)),
                     (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor)),
                     (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_img)
    elif event == cv2.EVENT_LBUTTONDBLCLK:
        roi_done = True
        if len(roi_points) > 2:
            cv2.line(display_img,
                     (int(roi_points[-1][0] * resize_factor), int(roi_points[-1][1] * resize_factor)),
                     (int(roi_points[0][0] * resize_factor), int(roi_points[0][1] * resize_factor)),
                     (0, 255, 255), 1)
        cv2.imshow("Draw ROI (double-click to finish)", display_img)

# --- Draw polygon and collect points ---
cv2.namedWindow("Draw ROI (double-click to finish)")
cv2.setMouseCallback("Draw ROI (double-click to finish)", mouse_callback)
cv2.imshow("Draw ROI (double-click to finish)", display_img)
print("Click to define ROI. Double-click to close.")
while not roi_done:
    cv2.waitKey(10)
cv2.destroyAllWindows()

if len(roi_points) < 3:
    raise ValueError("At least 3 points needed for polygon.")

# --- Create ROI mask ---
mask = np.zeros((h, w), dtype=np.uint8)
cv2.fillPoly(mask, [np.array(roi_points, dtype=np.int32)], 255)

# --- Extract ROI pixels ---
roi_pixels = image[mask == 255].reshape(-1, 1).astype(np.float32)

# --- Gaussian Mixture Model ---
gmm = GaussianMixture(n_components=k, covariance_type='full', random_state=0)
gmm.fit(roi_pixels)
labels = gmm.predict(roi_pixels)

# --- Thermal color mapping ---
thermal_colors = {
    0: (255, 0, 0),      # Blue = Cold
    1: (255, 165, 0),    # Orange = Medium
    2: (0, 0, 255),      # Red = Hot
    3: (255, 255, 255),  # White = Very hot (optional)
}

# --- Build colored output image ---
colored_result = np.zeros((h, w, 3), dtype=np.uint8)
flat = colored_result.reshape(-1, 3)
roi_indices = np.flatnonzero(mask.flatten())

for i, idx in enumerate(roi_indices):
    color = thermal_colors.get(labels[i], (255, 255, 255))  # fallback color
    flat[idx] = color

colored_result = flat.reshape((h, w, 3))

# --- Show result ---
plt.figure(figsize=(6, 6))
plt.title(f"GMM Clustering in ROI (k={k})")
plt.imshow(cv2.cvtColor(colored_result, cv2.COLOR_BGR2RGB))
plt.axis('off')
plt.tight_layout()
plt.show()
