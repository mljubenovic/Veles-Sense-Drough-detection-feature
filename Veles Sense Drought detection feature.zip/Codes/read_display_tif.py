import rasterio
import matplotlib.pyplot as plt
import numpy as np

# Path to your TIF file
tif_path = "C:/Users/ljube/Desktop/Veles_Sense/Projekti/EmpoWomen/implementation/Thermal_implementation/Data/2025_08_08_Radovanovic/2025_08_08_Radovanovic_Termal_LevoVikendica_50m_ortho.TIF"

# Open the TIF file
with rasterio.open(tif_path) as src:
    # Read the first band
    band1 = src.read(1)

    # Show basic metadata
    print("Width:", src.width)
    print("Height:", src.height)
    print("CRS:", src.crs)
    print("Number of bands:", src.count)

# Display the image

# Robust contrast: clip to 2–98% percentiles so the image isn't all black/white
p2, p98 = np.percentile(band1, [2, 98])

plt.figure(figsize=(7, 6))
plt.imshow(band1, cmap="inferno", vmin=p2, vmax=p98)  # 'inferno' = thermal-like
plt.axis("off")
plt.title("Thermal image (auto-stretched, inferno colormap)")
plt.colorbar(label="Relative temperature (scaled)")
plt.show()
